package com.app.restaurantmanagementapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.databinding.AdminMenuItemBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class AdminMenuAdapter extends RecyclerView.Adapter<AdminMenuAdapter.ViewHolder>  {

    private final LayoutInflater mInflater;
    private final List<MenuItemModel> mList;
    private final ClickListener clickListener;
    private final Context context;
    private MenuItemModel menuItem;


    public AdminMenuAdapter(Context context, List<MenuItemModel> mList,ClickListener clickListener) {
        this.mList = mList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public AdminMenuAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AdminMenuItemBinding binding =
                DataBindingUtil.inflate(mInflater, R.layout.admin_menu_item, parent, false);
        return new AdminMenuAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminMenuAdapter.ViewHolder holder, int position) {

        menuItem = mList.get(position);
        holder.binding.tvName.setText(menuItem.getName());
        holder.binding.tvCategory.setText(menuItem.getCategory());
        holder.binding.tvPrice.setText(menuItem.getPrice() + " Rs");

        //Delete Listener
        holder.binding.ivDelete.setOnClickListener(view -> {
            //Deleting
         clickListener.onClick(position,"delete");
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        AdminMenuItemBinding binding;

        ViewHolder(AdminMenuItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

