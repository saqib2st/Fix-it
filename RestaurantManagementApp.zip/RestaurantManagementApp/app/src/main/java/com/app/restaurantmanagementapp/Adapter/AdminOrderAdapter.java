package com.app.restaurantmanagementapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.databinding.AdminMenuItemBinding;
import com.app.restaurantmanagementapp.databinding.AdminOrderLayoutBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.ViewHolder>  {

    private final LayoutInflater mInflater;
    private final List<OrderModel> mList;
    private final ClickListener clickListener;
    private final Context context;
    private OrderModel orderModel;
    private String name;


    public AdminOrderAdapter(Context context, List<OrderModel> mList,ClickListener clickListener) {
        this.mList = mList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public AdminOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AdminOrderLayoutBinding binding =
                DataBindingUtil.inflate(mInflater, R.layout.admin_order_layout, parent, false);
        return new AdminOrderAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminOrderAdapter.ViewHolder holder, int position) {

        orderModel = mList.get(position);
        //GETTING USER NAME
        FirebaseFirestore.getInstance().collection("Users").document(orderModel.getUserId()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                name = documentSnapshot.getString("name");
            }
        });

        holder.binding.tvOrderedBy.setText("Ordered by: " + name);
        holder.binding.tvItems.setText("Items: " + orderModel.getItemName());
        holder.binding.tvQuantity.setText("Quantity: " + orderModel.getQuantity());
        holder.binding.tvBill.setText("Total bill: " + orderModel.getPrice() + " Rs.");


        //Delete Listener
        holder.binding.ivDelete.setOnClickListener(view -> {
           clickListener.onClick(position,"delete");
        });
        holder.binding.spinnerBillStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    clickListener.onClick(position,"bill_unpaid");
                }else if (i == 1){
                    clickListener.onClick(position,"bill_paid");
                    holder.binding.ivDone.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        holder.binding.spinnerOrderStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 1){
                    clickListener.onClick(position,"order_cooking");
                }else if (i == 2){
                    clickListener.onClick(position,"order_served");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        AdminOrderLayoutBinding binding;

        ViewHolder(AdminOrderLayoutBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

