package com.app.restaurantmanagementapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.CartItemLayoutBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder>  {

private final LayoutInflater mInflater;
private final List<OrderModel> mList;
private final Context context;
private final ClickListener clickListener;
private OrderModel orderItem;


public CartAdapter(Context context, List<OrderModel> mList, ClickListener clickListener) {
        this.mList = mList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.clickListener = clickListener;
        }

@NonNull
@Override
public CartAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CartItemLayoutBinding binding =
        DataBindingUtil.inflate(mInflater, R.layout.cart_item_layout, parent, false);
        return new CartAdapter.ViewHolder(binding);
        }

@Override
public void onBindViewHolder(@NonNull CartAdapter.ViewHolder holder, int position) {

        orderItem = mList.get(position);
        holder.binding.tvName.setText(orderItem.getItemName());
        holder.binding.tvPrice.setText("Rs. " +orderItem.getPrice());
        holder.binding.tvQuantity.setText("Quantity: " + orderItem.getQuantity());
        holder.binding.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickListener.onClick(position,"delete");
            }
        });

}

@Override
public int getItemCount() {
        return mList.size();
        }

class ViewHolder extends RecyclerView.ViewHolder {
    CartItemLayoutBinding binding;

    ViewHolder(CartItemLayoutBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
    }
}

}
