package com.app.restaurantmanagementapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.databinding.AdminMenuItemBinding;
import com.app.restaurantmanagementapp.databinding.UserMenuItemLayoutBinding;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class CustomerMenuAdapter extends RecyclerView.Adapter<CustomerMenuAdapter.ViewHolder>  {

    private final LayoutInflater mInflater;
    private final List<MenuItemModel> mList;
    private final Context context;
    private final ClickListener clickListener;
    private MenuItemModel menuItem;


    public CustomerMenuAdapter(Context context, List<MenuItemModel> mList,ClickListener clickListener) {
        this.mList = mList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public CustomerMenuAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        UserMenuItemLayoutBinding binding =
                DataBindingUtil.inflate(mInflater, R.layout.user_menu_item_layout, parent, false);
        return new CustomerMenuAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerMenuAdapter.ViewHolder holder, int position) {

        menuItem = mList.get(position);
        holder.binding.tvName.setText(menuItem.getName());
        holder.binding.tvCategory.setText(menuItem.getCategory());
        holder.binding.tvPrice.setText(menuItem.getPrice() + " Rs");

        holder.binding.ivDetails.setOnClickListener(view -> {
            //Details
            clickListener.onClick(position,"view_more");
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickListener.onClick(position,"view_more");
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        UserMenuItemLayoutBinding binding;

        ViewHolder(UserMenuItemLayoutBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}
