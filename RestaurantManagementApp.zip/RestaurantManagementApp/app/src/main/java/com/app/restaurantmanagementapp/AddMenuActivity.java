package com.app.restaurantmanagementapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.ActivityAddMenuBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddMenuActivity extends AppCompatActivity {

    ActivityAddMenuBinding binding;
    private String qrCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_add_menu);
        initListener();
    }

    private void initListener() {
        binding.btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.etItemName.getText().toString().matches("")){
                    binding.etItemName.setError("Please enter name");
                    binding.etItemName.requestFocus();
                } else if (binding.etPrice.getText().toString().matches("")){
                    binding.etPrice.setError("Please enter price");
                    binding.etPrice.requestFocus();
                } else {
                    ProgressDialog progressDialog = new ProgressDialog(AddMenuActivity.this);
                    progressDialog.setMessage("Please Wait");
                    progressDialog.show();

                    //Setting document ID
                   String timeStamp = Utils.getTimeStamp();

                    //Getting QR
                    FirebaseDatabase.getInstance().getReference("QR-CODES").child(Utils.getCurrentUserId())
                            .addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                     qrCode = snapshot.child("QR-CODE").getValue(String.class);
                                    Toast.makeText(AddMenuActivity.this, qrCode, Toast.LENGTH_SHORT).show();

                                    //Creating Model
                                    MenuItemModel model = new MenuItemModel(Utils.getCurrentUserId() + timeStamp,binding.etItemName.getText().toString()
                                            ,binding.etPrice.getText().toString()
                                            ,binding.spinnerCategory.getSelectedItem().toString(),Utils.getCurrentUserId(),qrCode);

                                    FirebaseFirestore.getInstance().collection("Menu").document(Utils.getCurrentUserId() + timeStamp)
                                            .set(model).addOnSuccessListener(aVoid -> {
                                        progressDialog.dismiss();
                                        Toast.makeText(AddMenuActivity.this, "Item Added to your menu", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(),AdminHomeActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    });
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });



                }
            }
        });
    }
}