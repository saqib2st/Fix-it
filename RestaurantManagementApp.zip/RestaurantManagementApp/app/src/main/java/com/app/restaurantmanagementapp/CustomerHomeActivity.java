package com.app.restaurantmanagementapp;

import android.content.Intent;
import android.os.Bundle;

import com.app.restaurantmanagementapp.Fragments.CustomerHomeFragment;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.ui.main.CustomerPageAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.app.restaurantmanagementapp.ui.main.SectionsPagerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomerHomeActivity extends AppCompatActivity {

    private String qrCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);
        gettingIntentData();
        CustomerPageAdapter sectionsPagerAdapter = new CustomerPageAdapter(this, getSupportFragmentManager(),qrCode);
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        //Setting Icons
        tabs.getTabAt(0).setIcon(R.drawable.ic_menu_book);
        tabs.getTabAt(1).setIcon(R.drawable.ic_cart);


        FloatingActionButton fab = findViewById(R.id.fab);

        FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(Utils.getCurrentUserId())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            fab.setVisibility(View.VISIBLE);
                            fab.setOnClickListener(view -> {
                                Intent intent = new Intent(getApplicationContext(),OrderDetailActivity.class);
                                intent.putExtra("QR-CODE",qrCode);
                                startActivity(intent);
                            });
                        } else {
                            fab.setVisibility(View.INVISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    private void gettingIntentData() {
        Intent intent = getIntent();
        qrCode =  intent.getStringExtra("QR-CODE");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }

}