package com.app.restaurantmanagementapp.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Adapter.CustomerMenuAdapter;
import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.LoginActivity;
import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.FragmentCustomerHomeBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;


public class CustomerHomeFragment extends Fragment implements ClickListener {

    FragmentCustomerHomeBinding binding;
    private String qrCode;
    private ArrayList<MenuItemModel> mList = new ArrayList<>();
    private CustomerMenuAdapter adapter;
    int count = 1;
    private AlertDialog alertDialog;
    private CollectionReference menuRef = FirebaseFirestore.getInstance().collection("Menu");


    public CustomerHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_customer_home,container,false);
        initListener();
        setRecyclerView();
        return binding.getRoot();
    }

    private void initListener() {
        binding.btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getContext(), LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    private void setRecyclerView() {
        //Setting Recyclerview layout manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initObjects();

    }

    private void initObjects() {
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            qrCode = bundle.getString("QR-CODE");
            Log.i("QR-CODE",qrCode);
            getListOfMenu();
        }else {
            Log.i("QR-CODE","Not found");
        }
    }

    private void getListOfMenu() {
       // Query query = FirebaseFirestore.getInstance().collection("Menu").whereEqualTo("qrCode",qrCode);

       // FirebaseFirestore.getInstance().collection("Menu").

        menuRef
                .whereEqualTo("qrCode",qrCode)
                .get().addOnCompleteListener(task -> {
                    if(task.isSuccessful()){
                        mList.clear();{
                            for (DocumentSnapshot snapshot : task.getResult()){
                                MenuItemModel model = snapshot.toObject(MenuItemModel.class);
                                mList.add(model);
                                populateRecyclerView();
                            }
                        }
                    }
                });

    }


    private void populateRecyclerView() {
        if (mList != null && mList.size() < 1) {
            binding.tvNothingFound.setVisibility(View.VISIBLE);
            return;
        } else {
            binding.tvNothingFound.setVisibility(View.INVISIBLE);
            Log.i("TAG","Something's there");
        }
        if (adapter == null) {
            adapter = new CustomerMenuAdapter(getContext(), mList,this);
            binding.recyclerView.setAdapter(adapter);
        } else
            adapter.notifyDataSetChanged();

    }


    @Override
    public void onClick(int position, String message) {
        //Creating Model for Use
        MenuItemModel model = mList.get(position);

        if (message.matches("view_more")){
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getContext(),R.style.BottomSheetDialogTheme);

            View mView = LayoutInflater.from(getContext()).inflate(R.layout.product_details_bottom_sheet,
                    getView().findViewById(R.id.bottom_sheet_container));
         //   View mView = getLayoutInflater().inflate(R.layout.product_details_bottom_sheet, null);
            TextView title = mView.findViewById(R.id.tv_name);
            TextView price = mView.findViewById(R.id.tv_price);
            TextView quantity = mView.findViewById(R.id.tv_quantity);
            ImageView subtract = mView.findViewById(R.id.iv_subtract);
            ImageView add = mView.findViewById(R.id.iv_add);

            Button btnAddToCart = mView.findViewById(R.id.btn_add_to_cart);

            title.setText(model.getName());
            price.setText("Rs. " + model.getPrice());
            quantity.setText(String.valueOf(count));
            //Click Listeners
            subtract.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!quantity.getText().toString().matches("1")){
                        count--;
                        quantity.setText(String.valueOf(count));
                        double totalPrice = Integer.parseInt(model.getPrice()) * count;
                        price.setText("Rs. " + String.valueOf(totalPrice));
                    }
                }
            });
            add.setOnClickListener(view -> {
                count++;
                quantity.setText(String.valueOf(count));
                double totalPrice = Integer.parseInt(model.getPrice()) * count;
                price.setText("Rs. " + String.valueOf(totalPrice));
            });
            btnAddToCart.setOnClickListener(view -> {
                if (quantity.getText().toString().matches("0")){
                    Toast.makeText(getContext(), "Please enter quantity", Toast.LENGTH_SHORT).show();
                }else {
                    //GETTING Total Price
                    bottomSheetDialog.dismiss();
                    double totalPrice = Integer.parseInt(model.getPrice()) * count;
                   // Toast.makeText(getContext(), String.valueOf(totalPrice), Toast.LENGTH_SHORT).show();
                //Building OrderModel
                    String timeStamp = Utils.getTimeStamp();
                    OrderModel orderModel = new OrderModel(Utils.getCurrentUserId() + timeStamp,model.getName(),String.valueOf(totalPrice)
                    ,model.getCategory(),Utils.getCurrentUserId(),FirebaseAuth.getInstance().getCurrentUser().getDisplayName(),
                            Utils.getTimeStamp(),qrCode,"pending","false",quantity.getText().toString());

                    FirebaseDatabase.getInstance().getReference("Carts")
                            .child(qrCode).child(Utils.getCurrentUserId()).child(Utils.getCurrentUserId() + timeStamp).setValue(orderModel)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
                                        count = 1;
                                    }else {
                                        Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }
            });

            bottomSheetDialog.setOnCancelListener(dialogInterface -> {
                count = 1;
            });
            bottomSheetDialog.setContentView(mView);
            bottomSheetDialog.show();

        }
    }


}