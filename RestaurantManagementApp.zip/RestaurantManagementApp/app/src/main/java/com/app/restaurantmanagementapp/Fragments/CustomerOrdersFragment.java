package com.app.restaurantmanagementapp.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Adapter.CartAdapter;
import com.app.restaurantmanagementapp.Adapter.CustomerMenuAdapter;
import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.OrderDetailActivity;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.FragmentCustomerOrdersBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firestore.v1.StructuredQuery;

import java.util.ArrayList;

import io.grpc.okhttp.internal.Util;

public class CustomerOrdersFragment extends Fragment implements ClickListener {

    FragmentCustomerOrdersBinding binding;
   private ArrayList<OrderModel> mList = new ArrayList<>();
   private CartAdapter adapter;
   private double totalBill = 0;
    private String qrCode;
    private ArrayList<String> itemNames = new ArrayList<>();
    private ArrayList<String> quantities = new ArrayList<>();

    private String userName;


    public CustomerOrdersFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_customer_orders,container,false);
        initObjects();
        initListener();
        getListOfCartItems();
        return binding.getRoot();
    }

    private void initListener() {
        binding.btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Checking price once again
                //Checking if order exists
                FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(Utils.getCurrentUserId())
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists()){
                                    Toast.makeText(getContext(), "Please wait for completion of first order", Toast.LENGTH_SHORT).show();
                                }else {
                                    if (totalBill == 0){
                                        Toast.makeText(getContext(), "Please select any item", Toast.LENGTH_SHORT).show();
                                    } else {
                                        totalBill = 0;
                                        for (int counter = 0; counter < mList.size(); counter++) {
                                            totalBill = totalBill + Double.parseDouble(mList.get(counter).getPrice());
                                        }

                                        //Getting User Name
                                        FirebaseFirestore.getInstance().collection("Users").document(Utils.getCurrentUserId())
                                                .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                            @Override
                                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                userName = documentSnapshot.getString("name");
                                            }
                                        });


                                        String timeStamp = Utils.getTimeStamp();
                                        //Creating order model
                                        OrderModel orderModel = new OrderModel(Utils.getCurrentUserId() + timeStamp,itemNames.toString(),String.valueOf(totalBill)
                                                ,null,Utils.getCurrentUserId(),userName,Utils.getTimeStamp()
                                                ,qrCode,"Received","un-paid",quantities.toString());

                                        FirebaseDatabase.getInstance().getReference("Orders").child(qrCode)
                                                .child(Utils.getCurrentUserId()).setValue(orderModel)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()){
                                                            Toast.makeText(getContext(), "Order Placed Successfully", Toast.LENGTH_LONG).show();
                                                            //Clearing Cart
                                                            totalBill = 0;
                                                            binding.tvTotalPrice.setVisibility(View.INVISIBLE);
                                                            FirebaseDatabase.getInstance().getReference("Carts").child(qrCode).child(Utils.getCurrentUserId()).removeValue();
                                                            mList.clear();

                                                            //Launching Order Screen
                                                            Intent intent = new Intent(getContext(), OrderDetailActivity.class);
                                                            intent.putExtra("QR-CODE",qrCode);
                                                            startActivity(intent);

                                                        }else {
                                                            Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                                        }
                                                    }
                                                });
                                    }

                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });



            }
        });

    }


    private void getListOfCartItems() {
        FirebaseDatabase.getInstance().getReference("Carts").child(qrCode).child(Utils.getCurrentUserId())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        mList.clear();
                        totalBill  = 0;
                        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                            OrderModel orderModel = postSnapshot.getValue(OrderModel.class);
                            mList.add(orderModel);
                            itemNames.add(orderModel.getItemName());
                            quantities.add(orderModel.getQuantity());
                            totalBill = totalBill + Double.parseDouble(orderModel.getPrice());
                            populateRecyclerView();
                            //    mList.add(postSnapshot.getValue());
                        }
                        binding.tvTotalPrice.setText("Total Bill = " + String.valueOf(totalBill) + " Rs.");
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    private void populateRecyclerView() {
        if (mList != null && mList.size() < 1) {
            binding.tvNothingFound.setVisibility(View.VISIBLE);
            binding.tvTotalPrice.setVisibility(View.INVISIBLE);
            binding.btnPay.setVisibility(View.INVISIBLE);
            return;
        } else {
            binding.tvNothingFound.setVisibility(View.INVISIBLE);
            binding.tvTotalPrice.setVisibility(View.VISIBLE);
            binding.btnPay.setVisibility(View.VISIBLE);
            Log.i("TAG","Something's there");
        }
        if (adapter == null) {
            adapter = new CartAdapter(getContext(), mList,this);
            binding.recyclerView.setAdapter(adapter);
        } else
            adapter.notifyDataSetChanged();
    }

    private void initObjects() {
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            qrCode = bundle.getString("QR-CODE");
            Log.i("QR-CODE",qrCode);
        }else {
            Log.i("QR-CODE","Not found");
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
    }

    @Override
    public void onClick(int position, String message) {
        if (message.matches("delete")){
            FirebaseDatabase.getInstance().getReference("Carts").child(qrCode).child(Utils.getCurrentUserId())
                    .child(mList.get(position).getDocumentId())
//                    .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if (task.isSuccessful()){
//                        Toast.makeText(getContext(), "Deleted", Toast.LENGTH_SHORT).show();
//
//                        if(mList != null && mList.size() != 0){
//                            mList.remove(position);
//                            totalBill = 0;
//                            for (int counter = 0; counter < mList.size(); counter++) {
//                                totalBill = totalBill + Double.parseDouble(mList.get(counter).getPrice());
//                            }
//
//                            binding.tvTotalPrice.setText("Total Bill = " + String.valueOf(totalBill) + " Rs.");
//                        }
//                        adapter.notifyItemRemoved(position);
//
//                    }else {
//                        Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
            .removeValue();
            mList.remove(position);
                            totalBill = 0;
                            for (int counter = 0; counter < mList.size(); counter++) {
                                totalBill = totalBill + Double.parseDouble(mList.get(counter).getPrice());
                            }
                            adapter.notifyItemRemoved(position);

            //Removing item name and quantities
            itemNames.remove(position);
            quantities.remove(position);
        }

    }
}