package com.app.restaurantmanagementapp.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Adapter.AdminMenuAdapter;
import com.app.restaurantmanagementapp.AddMenuActivity;
import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.MenuItemModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.FragmentHotelMenuBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class HotelMenuFragment extends Fragment implements ClickListener {

    FragmentHotelMenuBinding binding;
    AdminMenuAdapter adapter;
    ArrayList<MenuItemModel> mList = new ArrayList<>();
    MenuItemModel model;
    String qrCode;



    public HotelMenuFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_hotel_menu,container,false);
        initObjects();
        checkingIfMenuExists();

        initListener();
        return binding.getRoot();
    }

    private void checkingIfMenuExists() {
        FirebaseDatabase.getInstance().getReference("QR-CODES").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(Utils.getCurrentUserId()).exists()){
                    getMenuItems();
                } else {
                    binding.tvNothingFound.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getMenuItems() {
        FirebaseDatabase.getInstance().getReference("QR-CODES").child(Utils.getCurrentUserId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                qrCode = snapshot.child("QR-CODE").getValue().toString();

                FirebaseFirestore.getInstance().collection("Menu").whereEqualTo("qrCode",qrCode).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){
                            mList.clear();
                            for (QueryDocumentSnapshot documentSnapshot : task.getResult()){
                                    model = documentSnapshot.toObject(MenuItemModel.class);
                                    mList.add(model);
                                    populateRecyclerView();
                            }
                        }
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    private void initObjects() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
    }


    private void populateRecyclerView() {
        if (mList != null && mList.size() < 1) {
            binding.tvNothingFound.setVisibility(View.VISIBLE);

            return;
        } else {
            binding.tvNothingFound.setVisibility(View.INVISIBLE);
            Log.i("TAG","Something's there");
        }
        if (adapter == null) {
            adapter = new AdminMenuAdapter(getContext(), mList,this);

            binding.recyclerView.setAdapter(adapter);
        } else
            adapter.notifyDataSetChanged();
    }

    private void initListener() {
        binding.fbtAddMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), AddMenuActivity.class));
            }
        });
    }

    @Override
    public void onClick(int position, String message) {
        if (message.matches("delete")){
            FirebaseFirestore.getInstance().collection("Menu").document(mList.get(position).getDocumentId()).delete();
            mList.remove(position);
            adapter.notifyItemRemoved(position);
        }
    }
}