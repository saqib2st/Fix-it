package com.app.restaurantmanagementapp.Fragments;

import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Adapter.AdminOrderAdapter;
import com.app.restaurantmanagementapp.Adapter.CartAdapter;
import com.app.restaurantmanagementapp.Interface.ClickListener;
import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.FragmentHotelOrdersBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.ArrayList;


public class HotelOrdersFragment extends Fragment implements ClickListener {

    FragmentHotelOrdersBinding binding;
    private ArrayList<OrderModel> mList = new ArrayList<>();
    private AdminOrderAdapter adapter;
    private String qrCode;


    public HotelOrdersFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_hotel_orders,container,false);
        initObjects();
        gettingQr();
        return binding.getRoot();
    }

    private void gettingQr() {
        FirebaseDatabase.getInstance().getReference("QR-CODES").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(Utils.getCurrentUserId()).exists()) {
                     qrCode = snapshot.child(Utils.getCurrentUserId()).child("QR-CODE").getValue(String.class);
                     getListOfOrders(qrCode);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getListOfOrders(String code) {
        FirebaseDatabase.getInstance().getReference("Orders").child(code)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        mList.clear();
                        for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                            OrderModel orderModel = postSnapshot.getValue(OrderModel.class);
                            mList.add(orderModel);
//                            itemNames.add(orderModel.getItemName());
//                            quantities.add(orderModel.getQuantity());
//                            totalBill = totalBill + Double.parseDouble(orderModel.getPrice());
                            populateRecyclerView();
                            //    mList.add(postSnapshot.getValue());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }



    private void populateRecyclerView() {
        if (mList != null && mList.size() < 1) {
            binding.tvNothingFound.setVisibility(View.VISIBLE);
            return;
        } else {
            binding.tvNothingFound.setVisibility(View.INVISIBLE);
            Log.i("TAG","Something's there");
        }
        if (adapter == null) {
            adapter = new AdminOrderAdapter(getContext(), mList,this);
            binding.recyclerView.setAdapter(adapter);
        } else
            adapter.notifyDataSetChanged();
    }

    private void initObjects() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        binding.recyclerView.setLayoutManager(linearLayoutManager);
    }

    @Override
    public void onClick(int position, String message) {
        if (message.matches("delete")){
            FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(mList.get(position).getDocumentId())
                    .removeValue();
            mList.remove(position);
            adapter.notifyItemRemoved(position);
        } else if(message.matches("bill_paid")){
            Toast.makeText(getContext(), "Bill Paid ", Toast.LENGTH_SHORT).show();
            //Updating
            DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(mList.get(position).getUserId());
            mDatabase.child("paymentStatus").setValue("Paid");

        } else if (message.matches("order_cooking")) {
            Toast.makeText(getContext(), "Preparing Order", Toast.LENGTH_SHORT).show();
            DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(mList.get(position).getUserId());
            mDatabase.child("orderStatus").setValue("Cooking");
        }
        else if (message.matches("order_served")) {
            Toast.makeText(getContext(), "Order Served", Toast.LENGTH_SHORT).show();
            DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(mList.get(position).getUserId());
            mDatabase.child("orderStatus").setValue("Served");
        }
    }

    @Override
    public void onStart() {
        super.onStart();

    }
}