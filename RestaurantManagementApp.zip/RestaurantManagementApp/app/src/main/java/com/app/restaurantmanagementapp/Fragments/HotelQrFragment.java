package com.app.restaurantmanagementapp.Fragments;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.restaurantmanagementapp.LoginActivity;
import com.app.restaurantmanagementapp.R;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.FragmentHotelQrBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.journeyapps.barcodescanner.Util;

import java.util.HashMap;


public class HotelQrFragment extends Fragment {

    FragmentHotelQrBinding binding;

    public HotelQrFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_hotel_qr,container,false);
        //Check if QR Exists from Realtime DataBase
        checkingIfQrExists();
        initListener();
        return binding.getRoot();
    }

    private void checkingIfQrExists() {
        FirebaseDatabase.getInstance().getReference("QR-CODES").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(Utils.getCurrentUserId()).exists()) {
                    binding.linearLayoutCreateQr.setVisibility(View.GONE);
                    //Exists So show bitmap on Image
//                   String code = String.valueOf(snapshot.child(Utils.getCurrentUserId()).getValue());
                   String code = snapshot.child(Utils.getCurrentUserId()).child("QR-CODE").getValue(String.class);

                    try {
                        MultiFormatWriter writer = new MultiFormatWriter();
                        BitMatrix matrix = writer.encode(code, BarcodeFormat.QR_CODE,350,350);
                        BarcodeEncoder encoder = new BarcodeEncoder();
                        Bitmap bitmap = encoder.createBitmap(matrix);
                        binding.ivQr.setImageBitmap(bitmap);
                        binding.tvQr.setText(code);
                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void initListener()  {
        binding.button.setOnClickListener(view -> {
            if (binding.etQrText.getText().toString().matches("")){
                binding.etQrText.setError("Please enter content");
                binding.etQrText.requestFocus();
            }else {
                try {
                    MultiFormatWriter writer = new MultiFormatWriter();
                    BitMatrix matrix = writer.encode(binding.etQrText.getText().toString(), BarcodeFormat.QR_CODE, 350, 350);
                    BarcodeEncoder encoder = new BarcodeEncoder();
                    Bitmap bitmap = encoder.createBitmap(matrix);
                    binding.ivQr.setImageBitmap(bitmap);
                    binding.tvQr.setText(binding.etQrText.getText());
                    binding.linearLayoutCreateQr.setVisibility(View.GONE);
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("QR-CODE", binding.etQrText.getText().toString());
                    //Uploading for menu
                    FirebaseDatabase.getInstance().getReference("QR-CODES").child(binding.etQrText.getText().toString())
                            .setValue(hashMap).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(getContext(), "QR Code Created Successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                    //Uploading for recheck
                    FirebaseDatabase.getInstance().getReference("QR-CODES").child(Utils.getCurrentUserId())
                            .setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Log.i("TAG","QR_CODE_SUCCESS");
                            }
                        }
                    });
                    
                } catch (WriterException e) {
                    e.printStackTrace();
                }

            }
        });
        binding.floatingActionButton.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(getContext(), LoginActivity.class));
            getActivity().finish();
        });
    }

}