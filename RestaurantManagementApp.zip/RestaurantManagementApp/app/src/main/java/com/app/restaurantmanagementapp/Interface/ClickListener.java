package com.app.restaurantmanagementapp.Interface;

public interface ClickListener {
    void onClick(int position, String message);
}
