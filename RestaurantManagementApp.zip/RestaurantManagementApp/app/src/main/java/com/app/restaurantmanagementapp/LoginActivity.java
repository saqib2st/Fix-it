package com.app.restaurantmanagementapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.tv.TvContract;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Fragments.CustomerHomeFragment;
import com.app.restaurantmanagementapp.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

import io.grpc.okhttp.internal.Util;

public class LoginActivity extends AppCompatActivity {


    ActivityLoginBinding binding;
   private boolean isAdmin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_login);
        initListener();
    }

    private void checkingIfAdmin() {
      //Checking if Admin
        ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();

        FirebaseDatabase.getInstance().getReference("Admin").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    //Is Admin
                    progressDialog.dismiss();
                    Intent intent = new Intent(getApplicationContext(),AdminHomeActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }else {
                    progressDialog.dismiss();
                    Intent intent = new Intent(getApplicationContext(),ScanQrActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);

                    //This was for testing only
//                    String qrCode = "My Restaurant";
//                    //
//                    Bundle bundle = new Bundle();
//                    bundle.putString("QR-CODE",qrCode);
//                    // set Fragmentclass Arguments
//                    CustomerHomeFragment fragobj = new CustomerHomeFragment();
//                    fragobj.setArguments(bundle);
//
//                    Intent intent = new Intent(getApplicationContext(),CustomerHomeActivity.class);
//                    intent.putExtra("QR-CODE",qrCode);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
//                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void initListener() {
        binding.tvToSignUp.setOnClickListener(view -> startActivity(new Intent(getApplicationContext(),RegisterActivity.class)));
        binding.tvAdminLogin.setOnClickListener(view -> {
            if(!isAdmin) {
                binding.textView2.setText("Admin Login");
                binding.tvToSignUp.setVisibility(View.INVISIBLE);
                binding.etEmail.setHint("Enter Admin Email");
                binding.etPassword.setHint("Enter Admin Password");
                binding.textView.setText("Click here to login as customer");
                isAdmin = true;
            }
            else if(isAdmin){
                binding.textView2.setText("Customer Login");
            binding.tvToSignUp.setVisibility(View.VISIBLE);
            binding.etEmail.setHint("Enter Email");
            binding.etPassword.setHint("Enter Password");
            binding.textView.setText("Click here to login as admin");
            isAdmin = false;
            }
        });
        binding.btnLogin.setOnClickListener(view -> {
           if (binding.etEmail.getText().toString().matches("")){
                binding.etEmail.setError("Please enter email");
                binding.etEmail.requestFocus();
            } else if (binding.etPassword.getText().toString().matches("")){
               binding.etPassword.setError("Please enter password");
               binding.etEmail.requestFocus();
           }else {
               ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
               progressDialog.setMessage("Please wait");
               progressDialog.show();

               FirebaseAuth.getInstance().signInWithEmailAndPassword(binding.etEmail.getText().toString(), binding.etPassword.getText().toString())
                       .addOnCompleteListener(task -> {
                           if (task.isSuccessful()){
                               progressDialog.dismiss();
                               if (isAdmin) {
                                   startActivity(new Intent(getApplicationContext(),AdminHomeActivity.class));
                               }else {
                                   startActivity(new Intent(getApplicationContext(),ScanQrActivity.class));
                               }
                           } else {
                               progressDialog.dismiss();
                               Toast.makeText(this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                           }
                       });
           }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (FirebaseAuth.getInstance().getCurrentUser() != null){
            checkingIfAdmin();
          //  FirebaseAuth.getInstance().signOut();
        }
    }

}