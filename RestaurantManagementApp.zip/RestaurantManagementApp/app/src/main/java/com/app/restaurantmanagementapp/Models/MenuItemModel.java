package com.app.restaurantmanagementapp.Models;

import java.io.Serializable;

public class MenuItemModel implements Serializable {
    private String documentId;
    private String name;
    private String price;
    private String category;
    private String userId;
    private String qrCode;

    public MenuItemModel() {
    }

    public MenuItemModel(String documentId, String name, String price, String category, String userId, String qrCode) {
        this.documentId = documentId;
        this.name = name;
        this.price = price;
        this.category = category;
        this.userId = userId;
        this.qrCode = qrCode;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
