package com.app.restaurantmanagementapp.Models;

import java.io.Serializable;

public class OrderModel implements Serializable {

    private String documentId;
    private String itemName;
    private String price;
    private String category;
    private String userId;
    private String name;
    private String timeStamp;
    private String qrCode;
    private String orderStatus;
    private String paymentStatus;
    private String quantity;


    public OrderModel() {
    }

    public OrderModel(String documentId, String itemName, String price, String category, String userId, String name, String timeStamp, String qrCode, String orderStatus, String paymentStatus, String quantity) {
        this.documentId = documentId;
        this.itemName = itemName;
        this.price = price;
        this.category = category;
        this.userId = userId;
        this.name = name;
        this.timeStamp = timeStamp;
        this.qrCode = qrCode;
        this.orderStatus = orderStatus;
        this.paymentStatus = paymentStatus;
        this.quantity = quantity;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
