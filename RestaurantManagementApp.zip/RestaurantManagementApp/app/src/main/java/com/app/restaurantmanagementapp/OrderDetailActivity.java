package com.app.restaurantmanagementapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.app.restaurantmanagementapp.Models.OrderModel;
import com.app.restaurantmanagementapp.Utils.Utils;
import com.app.restaurantmanagementapp.databinding.ActivityOrderDetailBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class OrderDetailActivity extends AppCompatActivity {


    ActivityOrderDetailBinding binding;
    String qrCode;
    private OrderModel orderModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_order_detail);
        initListener();
        initObjects();
    }

    private void initListener() {
        binding.ivBack.setOnClickListener(view -> finish());
//        binding.ivDelete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                AlertDialog alertDialog = new AlertDialog.Builder(OrderDetailActivity.this).create();
//                alertDialog.setTitle("Warning");
//                alertDialog.setMessage("Are you sure you want to remove this order");
//                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        dialogInterface.dismiss();
//                    }
//                });
//                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
//                        new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//                                FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(Utils.getCurrentUserId())
//                                        .removeValue();
//                                dialog.dismiss();
//                                finish();
//                            }
//                        });
//                alertDialog.show();
//            }
//        });

    }

    private void initObjects() {
        Intent intent = getIntent();
        qrCode = intent.getStringExtra("QR-CODE");

        FirebaseDatabase.getInstance().getReference("Orders").child(qrCode).child(Utils.getCurrentUserId())
         .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        orderModel = snapshot.getValue(OrderModel.class);
                        binding.tvOrderStatus.setText("Order Status:  " + orderModel.getOrderStatus());
                        binding.tvBill.setText("Total Bill: " + orderModel.getPrice() + " Rs.");
                        binding.tvName.setText("Items: " + orderModel.getItemName());
                        binding.tvBillStatus.setText("Bill Status:  " + orderModel.getPaymentStatus());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

}