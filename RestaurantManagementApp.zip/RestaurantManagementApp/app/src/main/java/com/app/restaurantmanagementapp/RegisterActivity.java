package com.app.restaurantmanagementapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Models.UserModel;
import com.app.restaurantmanagementapp.databinding.ActivityRegisterBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class RegisterActivity extends AppCompatActivity {

    ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       binding = DataBindingUtil.setContentView(this,R.layout.activity_register);
       initListener();
    }

    private void initListener() {
        binding.tvToLogin.setOnClickListener(view -> startActivity(new Intent(getApplicationContext(),LoginActivity.class)));
        binding.btnSignUp.setOnClickListener(view -> {
            if (binding.etName.getText().toString().matches("")){
                binding.etName.setError("Please enter name");
                binding.etName.requestFocus();
            } else if (binding.etMobileNumber.getText().toString().matches("")){
                binding.etMobileNumber.setError("Please enter mobile number");
                binding.etMobileNumber.requestFocus();
            } else if (binding.etEmail.getText().toString().matches("")){
                binding.etEmail.setError("Please enter email");
                binding.etEmail.requestFocus();
            } else if (binding.etPassword.getText().toString().matches("")){
                binding.etPassword.setError("Please enter password");
                binding.etPassword.requestFocus();
            }
            else {

                UserModel userModel = new UserModel(binding.etName.getText().toString().trim(),binding.etEmail.getText().toString().trim(),
                        binding.etMobileNumber.getText().toString().trim(),
                        binding.etPassword.getText().toString().trim());
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(userModel.getEmail(),userModel.getPassword()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            uploadToFirestore(userModel);
                        }
                    }
                });
            }
        });
    }

    private void uploadToFirestore(UserModel userModel) {
        FirebaseFirestore.getInstance().collection("Users").document(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .set(userModel).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(RegisterActivity.this, "Sign up successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), ScanQrActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }else {
                    Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}