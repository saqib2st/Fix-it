package com.app.restaurantmanagementapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.app.restaurantmanagementapp.Fragments.CustomerHomeFragment;
import com.app.restaurantmanagementapp.Utils.Capture;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class ScanQrActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qr);
        //Starting Camera

        IntentIntegrator intentIntegrator = new IntentIntegrator(ScanQrActivity.this);
        //Set prompt text
        intentIntegrator.setPrompt("For flash use volume up key");
        intentIntegrator.setBeepEnabled(true);
        intentIntegrator.setOrientationLocked(true);
        intentIntegrator.setCaptureActivity(Capture.class);
        intentIntegrator.initiateScan();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if (intentResult.getContents() != null){
            //Got Result
            Toast.makeText(this,intentResult.getContents(), Toast.LENGTH_SHORT).show();
            String qrCode = intentResult.getContents();
            //
            Bundle bundle = new Bundle();
            bundle.putString("QR-CODE",qrCode);
            // set Fragmentclass Arguments
            CustomerHomeFragment fragobj = new CustomerHomeFragment();
            fragobj.setArguments(bundle);

            Intent intent = new Intent(getApplicationContext(),CustomerHomeActivity.class);
            intent.putExtra("QR-CODE",qrCode);
            startActivity(intent);
        }else {
            Toast.makeText(this, "Unable to Detect anything !!!", Toast.LENGTH_SHORT).show();
        }
    }
}