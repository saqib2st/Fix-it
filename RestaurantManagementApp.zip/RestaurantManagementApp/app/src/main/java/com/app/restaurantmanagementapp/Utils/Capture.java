package com.app.restaurantmanagementapp.Utils;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
