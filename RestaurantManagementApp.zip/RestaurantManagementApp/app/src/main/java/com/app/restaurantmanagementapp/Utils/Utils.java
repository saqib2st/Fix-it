package com.app.restaurantmanagementapp.Utils;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Utils {

    public static String getTimeStamp() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 0);
        return String.valueOf(calendar.getTime().getTime());
    }

    public static String getFormattedDate() {
        return new SimpleDateFormat("yyyy.MMMMM.dd").format(new Date());
    }

    public static String getLastMonthTimeStamp() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        return String.valueOf(calendar.getTime().getTime());
    }

    public static String getCurrentUserId() {
        try {
            return FirebaseAuth.getInstance().getCurrentUser().getUid();
        } catch (NullPointerException e) {
        }
        return "";
    }

    public static String getLocalTime() {
        return java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
    }
}
