package com.app.restaurantmanagementapp.ui.main;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.app.restaurantmanagementapp.Fragments.CustomerHomeFragment;
import com.app.restaurantmanagementapp.Fragments.CustomerOrdersFragment;
import com.app.restaurantmanagementapp.R;

public class CustomerPageAdapter extends FragmentPagerAdapter {
    @StringRes
    private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_3};
    private final Context mContext;
    private final String qrCode;

    public CustomerPageAdapter(Context context, FragmentManager fm, String qrCode) {
        super(fm);
        mContext = context;
        this.qrCode = qrCode;
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).
        Fragment fragment = null;
        if (position == 0){
            Bundle bundle = new Bundle();
            bundle.putString("QR-CODE",qrCode);
            // set Fragmentclass Arguments
            CustomerHomeFragment fragobj = new CustomerHomeFragment();
            fragobj.setArguments(bundle);
            fragment = fragobj;
        }else if (position == 1){
            Bundle bundle = new Bundle();
            bundle.putString("QR-CODE",qrCode);
            // set Fragmentclass Arguments
            CustomerOrdersFragment fragobj = new CustomerOrdersFragment();
            fragobj.setArguments(bundle);
            fragment = fragobj;
        }
        return fragment;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return 2;
    }
}
